import profileOne from "../public/image/5927577 2.png"
import LOGO from '../public/image/logo.svg.svg'
import FileImage from '../public/image/Group 131255 (1).png'
import QuestionImage from '../public/image/Group 897.png'
import uploadImage from '../public/image/Vector.svg'
import cardBg from '../public/image/card-bg.svg'
import loginWalpaper from '../public/image/Online test-pana (1) 1.png'
import MaleAvatar1 from '../public/image/titan.png'
import MaleAvatar2 from '../public/image/titan (1).png'
import MaleAvatar3 from '../public/image/titan (2).png'
import MaleAvatar4 from '../public/image/titan (3).png'
import FemaleAvatar1 from '../public/image/5927577 5.png'
import FemaleAvatar2 from '../public/image/5927577 6.png'
import FemaleAvatar3 from '../public/image/5927577 7.png'
import FemaleAvatar4 from '../public/image/5927577 8.png'
import Badge1 from '../public/image/badge1.svg'
import Badge2 from '../public/image/badge2.svg'
import Badge3 from '../public/image/badge3.svg'
import WarningIcon from '../public/image/warning-icon.png'
import Dash from '../public/image/Vector 79.png'
import Red from '../public/image/icon.png'
import Free from '../public/image/icon (1).png'
import coomingSoon from '../public/image/Screenshot 2023-10-11 200030 1.png'
import Error from '../public/image/404.png'
import successImg from '../public/image/image 25.svg'
import failureImg from '../public/image/image_processing20200108-11051-3zkuew 1.svg'
import institutionImage from '../public/image/search 1 (1).png'
 const Image = {
    student: profileOne,
    LOGO,
    Error,
    FileImage,
    QuestionImage,
    uploadImage,
    cardBg,
    Dash,
    Free,
    Red,
    loginWalpaper,
    MaleAvatar1,
    MaleAvatar2,
    MaleAvatar3,
    MaleAvatar4,
    FemaleAvatar1,
    FemaleAvatar2,
    FemaleAvatar3,
    FemaleAvatar4,
    badge1: Badge1,
    badge2: Badge2,
    badge3: Badge3,
    WarningIcon,
    coomingSoon,
    successImg,
    failureImg,
    institutionImage
}

export default Image